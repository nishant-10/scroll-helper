const radios = document.querySelectorAll('input[name="scrollMode"]');

const contents = document.querySelectorAll(".section-content");

const saveTextButton = document.getElementById("saveText");

const saveTextWarning = document.getElementById("saveTextWarning");

const hideButtonsToggle = document.getElementById("hideButtons");

function updateSections() {
  contents.forEach((content) => {
    content.style.display = "none";
  });

  const selected = document.querySelector('input[name="scrollMode"]:checked');

  selected.closest(".section").querySelector(".section-content").style.display =
    "block";
}

function saveSettings(settings) {
  return chrome.storage.local.set({ settings });
}

function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["settings"], (data) => {
      resolve(data.settings || getDefaultSettings());
    });
  });
}

function populateUI(settings) {
  const modeRadio = document.querySelector(
    `input[name="scrollMode"][value="${settings.mode}"]`,
  );
  if (modeRadio) {
    modeRadio.checked = true;
  }

  hideButtonsToggle.checked = Boolean(settings.hideButtons);

  if (settings.mode === "text") {
    document.getElementById("topText").value = settings.top || "";
    document.getElementById("bottomText").value = settings.bottom || "";
  } else if (settings.mode === "percent") {
    document.getElementById("topPercent").value = settings.top ?? "";
    document.getElementById("bottomPercent").value = settings.bottom ?? "";
  }

  updateSections();
}

// Writing to storage is enough: content.js applies it via chrome.storage.onChanged
// (all open tabs) and via storage.get on load (future/reloaded tabs).
async function saveAndApplySettings(settings) {
  await saveSettings(settings);
}

function getDefaultSettings() {
  return {
    mode: "default",
    top: 100,
    bottom: 100,
    hideButtons: false,
  };
}

function isScrollInputDataValid({ topValue, bottomValue, mode }) {
  if (mode === "default") {
    return {
      valid: true,
      message: "",
    };
  }

  if (
    mode === "percent" &&
    (typeof topValue !== "number" ||
      typeof bottomValue !== "number" ||
      isNaN(topValue) ||
      isNaN(bottomValue) ||
      topValue < 0 ||
      bottomValue < 0 ||
      topValue > 100 ||
      bottomValue > 100)
  ) {
    return {
      valid: false,
      message: "Percentage must be between 0 and 100.",
    };
  }
  if (
    mode === "text" &&
    (typeof topValue !== "string" ||
      typeof bottomValue !== "string" ||
      topValue.trim() === "" ||
      bottomValue.trim() === "")
  ) {
    return {
      valid: false,
      message: "Invalid text value.",
    };
  }
  if (mode !== "percent" && mode !== "text") {
    return {
      valid: false,
      message: "Please select a valid option.",
    };
  }
  return {
    valid: true,
    message: "",
  };
}

saveTextButton.addEventListener("click", async () => {
  //we expect either one [top text + bottom text] or [% value]
  const selectedMode = document.querySelector(
    'input[name="scrollMode"]:checked',
  ).value;
  let inputsAreValid = true; //use this to take final decision if we want to send data or show warnings
  let validationError = "";
  //by default, we set mode text and scroll to 100%, this is a worst case fallback
  let extensionSettings = getDefaultSettings();

  if (selectedMode === "text") {
    const topText = document.getElementById("topText").value;
    const bottomText = document.getElementById("bottomText").value;
    const inputValidation = isScrollInputDataValid({
      topValue: topText,
      bottomValue: bottomText,
      mode: selectedMode,
    });
    if (inputValidation.valid) {
      extensionSettings = {
        mode: "text",
        top: topText.trim(),
        bottom: bottomText.trim(),
      };
    } else {
      inputsAreValid = false;
      validationError = inputValidation.message;
    }
  } else if (selectedMode === "percent") {
    const topRaw = document.getElementById("topPercent").value.trim();
    const bottomRaw = document.getElementById("bottomPercent").value.trim();
    // Treat empty fields as invalid (Number("") is 0, which would silently pass).
    const topPercent = topRaw === "" ? NaN : Number(topRaw);
    const bottomPercent = bottomRaw === "" ? NaN : Number(bottomRaw);
    const inputValidation = isScrollInputDataValid({
      topValue: topPercent,
      bottomValue: bottomPercent,
      mode: selectedMode,
    });
    if (inputValidation.valid) {
      extensionSettings = {
        mode: "percent",
        top: topPercent,
        bottom: bottomPercent,
      };
    } else {
      inputsAreValid = false;
      validationError = inputValidation.message;
    }
  } else if (selectedMode === "default") {
    extensionSettings = {
      mode: "default",
      top: 100,
      bottom: 100,
    };
  } else {
    inputsAreValid = false;
  }
  //if all inputs are valid, send data to the chrome tab
  if (inputsAreValid) {
    const allExtensionSettings = {
      ...extensionSettings,
      hideButtons: hideButtonsToggle.checked,
    };
    await saveAndApplySettings(allExtensionSettings);
    saveTextWarning.style.display = "none";
    saveTextButton.textContent = "Saved!";
    setTimeout(() => {
      saveTextButton.textContent = "Save";
    }, 1500);
  } else {
    //warning UI
    saveTextWarning.style.display = "flex";
    saveTextWarning.textContent = validationError || "Something went wrong";
    saveTextButton.textContent = "Save";
  }
});

radios.forEach((radio) => {
  radio.addEventListener("change", updateSections);
});

hideButtonsToggle.addEventListener("change", async () => {
  const currentSettings = await loadSettings();
  await saveAndApplySettings({
    ...currentSettings,
    hideButtons: hideButtonsToggle.checked,
  });
});

document.querySelectorAll("input").forEach((input) => {
  input.addEventListener("input", () => {
    saveTextWarning.style.display = "none";
  });
});

loadSettings().then(populateUI);
